document.addEventListener("DOMContentLoaded", function () {
  const btn = document.getElementById("psynct-add-row");
  if (!btn) return;

  btn.addEventListener("click", function () {
    const tbody = document.getElementById("psynct-target-rows");
    const index = tbody.children.length;

    const row = `
        <tr>
            <td>
                <input type="url"
                    name="<?php echo WP_PSYNCT_OPTION; ?>[targets][${index}][target_url]"
                    class="regular-text">
            </td>
            <td>
                <input type="text"
                    readonly
                    name="<?php echo WP_PSYNCT_OPTION; ?>[targets][${index}][key]"
                    value=""
                    class="regular-text">
            </td>
        </tr>`;

    tbody.insertAdjacentHTML("beforeend", row);
  });
});
