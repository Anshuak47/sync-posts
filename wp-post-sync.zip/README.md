# sync-posts
A plugin to sync posts to multiple host sites using WP REST API, along with translations
